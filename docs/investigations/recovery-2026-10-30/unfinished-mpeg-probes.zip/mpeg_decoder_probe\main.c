#include <kernel.h>
#include <tamtypes.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "libmpeg.h"
#include "libmpeg_internal.h"

extern unsigned char probe_m2v[];
extern unsigned int size_probe_m2v;
static int sent;
static s64 pts;
static void *frame;
static unsigned size;
static int feed(void *unused) {
 volatile unsigned *chcr=(volatile unsigned *)0x1000B400;
 (void)unused;
 if (sent) return 0;
 sent=1;
 while (*chcr & 0x100) {}
 *(volatile unsigned *)0x1000B410=(unsigned)probe_m2v & 0x1fffffff;
 *(volatile unsigned *)0x1000B420=(size_probe_m2v+15)/16;
 *chcr=0x101;
 return 1;
}
static void *sequence(void *unused,MPEGSequenceInfo *seq) {
 (void)unused;
 size=seq->m_Width*seq->m_Height*4;
 frame=memalign(128,size);
 printf("[mpeg-probe] sequence=%dx%d size=%u\n",seq->m_Width,seq->m_Height,size);
 return frame;
}
int main(void) {
 int count=0;
 FILE *out;
 printf("[mpeg-probe] start bytes=%u\n",size_probe_m2v);
 FlushCache(0);
 MPEG_Initialize(feed,0,sequence,0,&pts);
 _MPEG_Set16(0);
 out=fopen("host:decoded.rgb","wb");
 if (!out) { printf("[mpeg-probe] output open failed\n"); SleepThread(); }
 while (count<5 && MPEG_Picture(frame,&pts)) {
  unsigned char *pixels=(unsigned char *)((unsigned)frame|0x20000000);
  unsigned i,hash=2166136261U;
  for(i=0;i<size;++i) hash=(hash^pixels[i])*16777619U;
  fwrite(pixels,1,size,out);
  printf("[mpeg-probe] frame=%d hash=%08x\n",count,hash);
  ++count;
 }
 fclose(out);
 printf("[mpeg-probe] done frames=%d\n",count);
 printf("[ps2rig] exit=%d\n",count==5?0:1);
 fflush(stdout);
 MPEG_Destroy();
 SleepThread();
 return 0;
}
