"""Host regressions for the actual MPEG-PS audio metadata probe."""
import os
from pathlib import Path
import subprocess
import tempfile
root = Path(__file__).resolve().parents[1]
s = (root / "src/SMS_ContainerMPEG_PS.c").read_text()
a = s.index("static int _fill_audio_parameters (")
b = s.index("}  /* end _fill_audio_parameters */", a) + len("}  /* end _fill_audio_parameters */")
function = s[a:b]
harness = r"""
#include <assert.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#define SMS_CodecID_MP2 1
#define SMS_CodecID_MP3 2
#define SMS_CodecID_AC3 3
#define SMS_CodecID_DTS 4
#define SMS_CodecID_PCM16BE 5
#define AC3_LFE 16
#define SMS_bswap32 __builtin_bswap32
static uint32_t SMS_unaligned32(const void *p) { uint32_t x; memcpy(&x,p,4); return x; }
typedef struct {int m_ID,m_SampleRate,m_BitRate,m_Channels;} Codec;
typedef struct {Codec *m_pCodec;int m_SampleRate;} SMS_Stream;
typedef struct FileContext FileContext;
struct FileContext {
 unsigned m_Pos,m_CurPos;
 int (*Read)(FileContext *,void *,unsigned);
 int (*Seek)(FileContext *,unsigned);
};
typedef struct {int m_FreeFmtFrameSize,m_SampleRate,m_BitRate,m_nChannels;} SMS_MPAInfo;
static int g_AC3Channels[8]={2,1,2,3,3,4,4,5};
static const unsigned char *input;
static unsigned input_size, read_limit, restored;
static int read_file(FileContext *ctx,void *p,unsigned n) {
 if(n>input_size)n=input_size;
 if(n>read_limit)n=read_limit;
 memcpy(p,input,n);ctx->m_CurPos+=n;return n;
}
static int seek_file(FileContext *ctx,unsigned pos) {restored=ctx->m_CurPos=pos;return pos;}
static int MP123_CheckHeader(uint32_t h) {(void)h;return 0;}
static int MP123_DecodeHeader(uint32_t h,SMS_MPAInfo *p) {(void)h;(void)p;return 1;}
static int AC3_SyncInfo(unsigned char *p,int *flags,int *rate,int *bitrate) {
 volatile unsigned char last=p[6];(void)last;
 if(p[0]!=0x0b||p[1]!=0x77)return 0;
 *flags=2;*rate=48000;*bitrate=192000;return 768;
}
static int DTS_SyncInfo(unsigned char *p,int *a,int *b,int *c,int *d) {
 volatile unsigned char last=p[15];(void)last;(void)a;(void)b;(void)c;(void)d;return 0;
}
static int DTS_Channels(int f) {(void)f;return 2;}
""" + function + r"""
int main(int argc,char **argv) {
 unsigned char payload[32]={0x0b,0x77,0,0,0,0x40,0x40};
 Codec codec={SMS_CodecID_AC3,0,0,0};
 SMS_Stream stream={&codec,0};
 FileContext ctx={20,100,read_file,seek_file};
 unsigned n;
 (void)argv;
 input=payload;input_size=7;read_limit=32;
 assert(_fill_audio_parameters(&ctx,&stream,7)==1);
 if(argc==1) assert(restored==100);
 /* Truncation must not let header parsers inspect unread bytes. */
 memset(payload,0,sizeof(payload));
 for(n=0;n<16;++n) {
  ctx.m_CurPos=100;input_size=n;read_limit=n;
  assert(_fill_audio_parameters(&ctx,&stream,n)==0);
  codec.m_ID=SMS_CodecID_DTS;
  assert(_fill_audio_parameters(&ctx,&stream,n)==0);
  codec.m_ID=SMS_CodecID_AC3;
 }
 return 0;
}
"""
with tempfile.TemporaryDirectory() as tmp:
    src=Path(tmp)/"test.c";exe=Path(tmp)/"test"
    src.write_text(harness)
    subprocess.run([os.environ.get("CC","cc"),"-g","-fsanitize=address,undefined",str(src),"-o",str(exe)],check=True)
    subprocess.run([str(exe)]+os.sys.argv[1:],check=True,timeout=15)
print("MPEG-PS audio probe: cursor restore and truncated headers passed")
